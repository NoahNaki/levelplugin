# Minimal implementation targets for LevelPlugin

## Port first

1. Resource pack font generation model:
   - Read or hardcode equivalent of `Pack/Images/images.yml`.
   - Generate image fonts with correct ascent per image.
   - Read or hardcode equivalent of `Pack/Lines/lines.yml`.
   - Generate dialogue line, answer line, info, and character-name fonts.

2. Renderer:
   - Use the generated image-specific fonts.
   - Use generated line-specific fonts.
   - Keep one actionbar string and pixel-offset cursor math.

3. Then gameplay:
   - Session/typewriter.
   - Scroll answers.
   - Actions/conditions/goto.
   - NPC integration.

## Do not port

- Metrics
- Update checker
- Shaded Adventure classes
- Shaded PacketEvents classes
- All shaded dependencies
- Bukkit metrics charts
