# LuxDialogues Important-Only Reference

This is a trimmed reference pack for recreating LuxDialogues behavior inside LevelPlugin.

It deliberately removes shaded dependencies like Adventure, PacketEvents, Gson, Bukkit helper libraries, etc.

## What is included

### `reference-resources/`
The important runtime/config/resource-pack files:

- `Pack/Images/images.yml` — image glyph definitions and **ascent values** for Y placement.
- `Pack/Lines/lines.yml` — generated text font definitions for dialogue/answer/info/name lines.
- `Pack/Lines/example_font.json` — template used for generated bitmap text fonts.
- `Pack/Widths/widths.json` — text width data.
- `Pack/Images/*.png` — HUD image ingredients.
- `Dialogues/default_example.yml`
- `Dialogues/kingdom_example.yml`
- `config.yml`

### `important-classes/`
Only LuxDialogues classes that are directly relevant to:
- resource-pack generation
- actionbar/HUD rendering
- dialogue flow
- actions/conditions/goto/replies
- scroll/range/chat listeners
- API data structures

### `javap-readable-bytecode/`
Readable `javap -c -p` output for the important class files.

This is not full Java source, but it is much easier to inspect than raw `.class` files when a Java decompiler is unavailable.

## Most important files for the current HUD problem

1. `reference-resources/Pack/Images/images.yml`
   - Stores image ascent values.
   - This is how LuxDialogues vertically places fog, dialogue box, answer box, character box, name box, and hand arrow.

2. `reference-resources/Pack/Lines/lines.yml`
   - Stores line ascent/spacing.
   - This is how LuxDialogues vertically places dialogue text lines, answer lines, info line, and character name.

3. `javap-readable-bytecode/org_aselstudios_luxdialogues_Utils_ResourceUtil.javap.txt`
   - Shows where font JSONs are generated from `images.yml` and `lines.yml`.

4. `javap-readable-bytecode/org_aselstudios_luxdialogues_Utils_BarUtil.javap.txt`
   - Actionbar/HUD string helper logic.

5. `javap-readable-bytecode/org_aselstudios_luxdialogues_Utils_ElementUtil.javap.txt`
   - Important for element/glyph construction.

## Key concept

LuxDialogues does not move HUD PNGs up/down in Java.

Minecraft actionbar has no direct Y-coordinate API.

LuxDialogues controls vertical position by generating multiple font JSON files with different `ascent` values.

Analogy:
- Current LevelPlugin renderer: one horizontal shelf, slide every sticker left/right.
- LuxDialogues: several transparent sheets/shelves at different heights, then each element is horizontally aligned on its own sheet.

That is why just changing Java offsets will never fully match LuxDialogues.
