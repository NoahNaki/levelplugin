# Codex Context: What matters from LuxDialogues

The important concept is that LuxDialogues controls HUD vertical placement through generated Minecraft font JSON `ascent` values.

Look for:
- `Pack/Images/images.yml`: image glyph ascent/height/file settings
- `Pack/Lines/lines.yml`: line/answer/name/info font ascent and spacing
- Resource generation utility that converts those YAML values into font JSON
- Actionbar/HUD renderer that composes glyphs using offset chars and custom fonts

The PNG files are omitted because they are already in the Nexo external pack.
