# LuxDialogues Important Source - No Binary Assets

This zip is intentionally trimmed for Codex.

## What was kept

- Important Java/source files if present
- YAML configs such as `Pack/Images/images.yml` and `Pack/Lines/lines.yml`
- Example dialogue YAML files
- JSON/font config files
- Notes / readable analysis files

## What was removed

- PNGs and other binary assets
- JAR/class files
- build outputs
- dependency/shaded-library noise

## Asset note

Where PNGs would have existed, `.REMOVED.txt` placeholder files were added.

The actual dialogue assets should already exist in the Nexo external pack:

`plugins/Nexo/pack/external_packs/levelplugin-dialogue-hud/assets/levelplugin_dialogue/`

## Goal for Codex

Use this zip to understand LuxDialogues' resource-pack/font-generation model, especially:

- `Pack/Images/images.yml`
- `Pack/Lines/lines.yml`
- Resource/font generation utility classes
- HUD/actionbar renderer classes
- example dialogue YAML files

Do not import binary assets from this zip. Use the existing Nexo pack assets instead.
