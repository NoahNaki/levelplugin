// File: src/me/nakilex/levelplugin/items/listeners/WeaponStatsListener.java
package me.nakilex.levelplugin.items.listeners;

import me.nakilex.levelplugin.items.data.WeaponType;
import me.nakilex.levelplugin.items.events.WeaponEquipEvent;
import me.nakilex.levelplugin.items.data.CustomItem;
import me.nakilex.levelplugin.items.managers.ItemManager;
import me.nakilex.levelplugin.player.attributes.managers.StatsManager;
import me.nakilex.levelplugin.player.classes.data.PlayerClass;
import me.nakilex.levelplugin.player.classes.managers.PlayerClassManager;
import me.nakilex.levelplugin.player.level.managers.LevelManager;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.inventory.ItemStack;

import java.util.Set;
import java.util.UUID;

public class WeaponStatsListener implements Listener {

    private final StatsManager statsManager = StatsManager.getInstance();
    private final PlayerClassManager classManager = PlayerClassManager.getInstance();
    private final ItemManager itemManager = ItemManager.getInstance();

    @EventHandler
    public void onWeaponEquip(WeaponEquipEvent event) {
        // 0) Ignore canceled events or if neither old nor new is a weapon
        if (event.isCancelled()) return;
        if (WeaponType.matchType(event.getOldWeapon()) == null
            && WeaponType.matchType(event.getNewWeapon()) == null) {
            return;
        }

        Player player = event.getPlayer();
        UUID puuid = player.getUniqueId();
        StatsManager stats = StatsManager.getInstance();
        Set<Integer> equipped = stats.getEquippedItems(puuid);

        //
        // 1) REMOVE OLD WEAPON’S STATS (only if it’s still in the “equipped” set AND was not broken)
        //
        ItemStack oldWeap = event.getOldWeapon();
        if (oldWeap != null && !oldWeap.getType().isAir()) {
            CustomItem inst = itemManager.getCustomItemFromItemStack(oldWeap);
            if (inst != null && equipped.contains(inst.getId())) {
                boolean wasBroken = inst.isBroken();
                StatsManager.PlayerStats ps = statsManager.getPlayerStats(puuid);

                Bukkit.getLogger().info(
                    "[WeaponStats] Removing old weapon (ID=" + inst.getId() +
                        ", broken=" + wasBroken + ") for player " + player.getName()
                );
                logPlayerStats("Before removal", puuid, ps);

                if (!wasBroken) {
                    // Subtract all the stats
                    removeWeaponStats(player, inst);
                    // Take it out of the “equipped” set
                    equipped.remove(inst.getId());
                    // Unregister from our holder map
                    itemManager.unregisterHolder(inst.getId());
                    Bukkit.getLogger().info("[WeaponStats] Removed stats for weapon ID=" + inst.getId());
                } else {
                    Bukkit.getLogger().info("[WeaponStats] Skipped removal because weapon was already broken.");
                }

                logPlayerStats("After removal", puuid, ps);
            }
        }

        //
        // 2) ADD NEW WEAPON’S STATS (only if it’s not in “equipped” yet AND not broken AND meets requirements)
        //
        ItemStack newWeap = event.getNewWeapon();
        if (newWeap != null && !newWeap.getType().isAir()) {
            CustomItem inst = itemManager.getCustomItemFromItemStack(newWeap);
            if (inst != null && !equipped.contains(inst.getId())) {
                boolean isBroken = inst.isBroken();
                int playerLevel = LevelManager.getInstance().getLevel(player);
                int requiredLevel = inst.getLevelRequirement();
                PlayerClass requiredClass;
                try {
                    requiredClass = PlayerClass.valueOf(inst.getClassRequirement().toUpperCase());
                } catch (IllegalArgumentException e) {
                    requiredClass = PlayerClass.VILLAGER;
                }
                PlayerClass playerClass = statsManager.getPlayerStats(puuid).playerClass;
                StatsManager.PlayerStats ps = statsManager.getPlayerStats(puuid);

                Bukkit.getLogger().info(
                    "[WeaponStats] Attempting to add new weapon (ID=" + inst.getId() +
                        ", broken=" + isBroken + ") for player " + player.getName()
                );
                logPlayerStats("Before addition", puuid, ps);

                if (isBroken) {
                    Bukkit.getLogger().info("[WeaponStats] Skipped addition because weapon is broken.");
                    player.sendMessage(ChatColor.YELLOW
                        + inst.getBaseName()
                        + " is broken and grants no bonuses."
                    );
                }
                else if (playerLevel < requiredLevel) {
                    Bukkit.getLogger().info(
                        "[WeaponStats] Skipped addition: player level "
                            + playerLevel + " < requiredLevel " + requiredLevel + "."
                    );
                    player.sendMessage(ChatColor.RED
                        + "You can hold "
                        + inst.getBaseName()
                        + " but lack the level to gain its stats."
                    );
                }
                else if (requiredClass != PlayerClass.VILLAGER
                    && requiredClass != playerClass
                ) {
                    Bukkit.getLogger().info(
                        "[WeaponStats] Skipped addition: player class "
                            + playerClass + " != required class " + requiredClass + "."
                    );
                    player.sendMessage(ChatColor.RED
                        + "You can hold "
                        + inst.getBaseName()
                        + " but lack the required class to gain its stats."
                    );
                }
                else {
                    // Add all the stats
                    addWeaponStats(player, inst);
                    // Put it into the “equipped” set
                    equipped.add(inst.getId());
                    // Register in our holder map so CustomItem.reduceDurability can find who holds it
                    itemManager.registerHolder(inst.getId(), puuid);
                    Bukkit.getLogger().info("[WeaponStats] Added stats for weapon ID=" + inst.getId());
                }

                logPlayerStats("After addition", puuid, ps);
            }
        }

        //
        // 3) Always recalc derived stats so changes show up immediately
        //
        stats.recalcDerivedStats(player);
    }

    private void addWeaponStats(Player player, CustomItem customItem) {
        StatsManager.PlayerStats ps = statsManager.getPlayerStats(player.getUniqueId());
        ps.bonusHealthStat   += customItem.getHp();
        ps.bonusDefenceStat  += customItem.getDef();
        ps.bonusStrength     += customItem.getStr();
        ps.bonusAgility      += customItem.getAgi();
        ps.bonusIntelligence += customItem.getIntel();
        ps.bonusDexterity    += customItem.getDex();
    }

    /**
     * CHANGED to public so CustomItem.reduceDurability(...) can call it directly.
     */
    public void removeWeaponStats(Player player, CustomItem customItem) {
        StatsManager.PlayerStats ps = statsManager.getPlayerStats(player.getUniqueId());
        ps.bonusHealthStat   -= customItem.getHp();
        ps.bonusDefenceStat  -= customItem.getDef();
        ps.bonusStrength     -= customItem.getStr();
        ps.bonusAgility      -= customItem.getAgi();
        ps.bonusIntelligence -= customItem.getIntel();
        ps.bonusDexterity    -= customItem.getDex();
    }

    /**
     * Logs every bonus‐stat field on a player's PlayerStats.
     */
    private void logPlayerStats(String prefix, UUID puuid, StatsManager.PlayerStats ps) {
        Bukkit.getLogger().info(
            "[WeaponStats] "
                + prefix
                + " stats for player UUID="
                + puuid
                + " => bonusHealth="
                + ps.bonusHealthStat
                + ", bonusDefence="
                + ps.bonusDefenceStat
                + ", bonusStrength="
                + ps.bonusStrength
                + ", bonusAgility="
                + ps.bonusAgility
                + ", bonusIntelligence="
                + ps.bonusIntelligence
                + ", bonusDexterity="
                + ps.bonusDexterity
        );
    }
}
