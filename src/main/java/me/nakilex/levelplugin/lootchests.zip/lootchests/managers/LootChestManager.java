package me.nakilex.levelplugin.lootchests.managers;

import me.nakilex.levelplugin.lootchests.config.ConfigManager;
import me.nakilex.levelplugin.lootchests.data.ChestData;
import me.nakilex.levelplugin.lootchests.utils.ParticleUtils;
import me.nakilex.levelplugin.items.data.CustomItem;
import me.nakilex.levelplugin.items.managers.ItemManager;
import me.nakilex.levelplugin.items.utils.ItemUtil;
import me.nakilex.levelplugin.potions.data.PotionInstance;
import me.nakilex.levelplugin.potions.data.PotionTemplate;
import me.nakilex.levelplugin.potions.managers.PotionManager;
import net.md_5.bungee.api.ChatColor;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.ArmorStand;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Random;

public class LootChestManager {

    private final JavaPlugin plugin;
    private final ConfigManager configManager;
    private CooldownManager cooldownManager;
    private final PotionManager potionManager; // New field

    // Each chest’s data (ID -> ChestData)
    private final List<ChestData> chestDataList = new ArrayList<>();

    // Track where we actually spawned each chest. chestId -> location
    private final java.util.Map<Integer, Location> spawnedChests = new java.util.HashMap<>();

    // For continuous particles: chestId -> repeating task
    private final java.util.Map<Integer, org.bukkit.scheduler.BukkitTask> chestParticleTasks = new java.util.HashMap<>();

    public LootChestManager(JavaPlugin plugin, ConfigManager configManager, CooldownManager cooldownManager, PotionManager potionManager) {
        this.plugin = plugin;
        this.configManager = configManager;
        this.cooldownManager = cooldownManager;
        this.potionManager = potionManager; // assign it here

        loadChestDataFromConfig();
        spawnAllChestsOnStartup();

        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            for (ChestData data : chestDataList) {
                Location loc = data.toLocation();
                if (loc != null && loc.getChunk().isLoaded()) {
                    spawnHologramForChest(data);
                }
            }
        }, 1L);
    }

    public void setCooldownManager(CooldownManager manager) {
        this.cooldownManager = manager;
    }

    // 1) Load from lootchests.yml
    private void loadChestDataFromConfig() {
        ConfigurationSection root = configManager.getLootChestsConfig().getConfigurationSection("loot_chests");
        if (root == null) {
            plugin.getLogger().warning("No 'loot_chests' section found!");
            return;
        }
        for (String key : root.getKeys(false)) {
            try {
                int chestId = Integer.parseInt(key);
                String coords = root.getString(key + ".coordinates", "0,0,0");
                String[] split = coords.split(",");
                double x = Double.parseDouble(split[0].trim());
                double y = Double.parseDouble(split[1].trim());
                double z = Double.parseDouble(split[2].trim());
                int tier = root.getInt(key + ".tier", 1);

                ChestData data = new ChestData(chestId, x, y, z, tier);
                chestDataList.add(data);
            } catch (Exception e) {
                plugin.getLogger().warning("Error loading chest ID: " + key);
            }
        }
    }

    // 2) Spawn all on startup
    private void spawnAllChestsOnStartup() {
        for (ChestData data : chestDataList) {
            spawnChest(data);
        }
    }


    // Inside LootChestManager.java

    public void spawnChest(ChestData data) {
        Location loc = data.toLocation();
        Block block = loc.getBlock();
        block.setType(Material.CHEST);
        spawnedChests.put(data.getChestId(), loc);
        org.bukkit.block.Chest chestState = (org.bukkit.block.Chest) block.getState();
        chestState.getBlockInventory().clear();

        ItemStack loot = getRandomLootForTier(data.getTier());

        // Add the item into a random slot
        Random random = new Random();
        int randomSlot = random.nextInt(chestState.getBlockInventory().getSize());

        chestState.update(true);

        // Start particle effect
        startParticleTask(data.getChestId(), loc, data.getTier());
        chestState.getBlockInventory().setItem(randomSlot, loot);

        // DEFER hologram spawn by 1 tick (ensures chunk is loaded)
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            plugin.getLogger().info("[LootChest] Deferred hologram spawn for chest " + data.getChestId());
            spawnHologramForChest(data);
        }, 1L);
    }


    // Still in LootChestManager.java

    public void spawnHologramForChest(ChestData data) {
        Location base = data.toLocation();
        if (base == null) {
            plugin.getLogger().warning("[Holo] No location for chest " + data.getChestId());
            return;
        }
        boolean chunkLoaded = base.getChunk().isLoaded();
        boolean isChest    = base.getBlock().getType() == Material.CHEST;

        // guard: valid location, chunk loaded, and block is still a CHEST
        if (!chunkLoaded || !isChest) {
            return;
        }

        // positions for each hologram line
        Location line1Loc = base.clone().add(0.5, 1.2, 0.5);
        Location line2Loc = base.clone().add(0.5, 0.95, 0.5);
        Location line3Loc = base.clone().add(0.5, 0.70, 0.5);

        String namePrefix = data.getCustomName().orElse("Loot Chest");
        String tierText   = "Tier " + toRoman(data.getTier());
        String text1      = formatTierLine(namePrefix, tierText, data.getTier());
        String text2      = "§fRight-Click §7to open";
        String text3      = data.getContentType()
            .map(t -> "§7[Contains: " + t + "]")
            .orElse(null);

        spawnArmorStand(line1Loc, text1, data);
        spawnArmorStand(line2Loc, text2, data);
        if (text3 != null) {
            spawnArmorStand(line3Loc, text3, data);
        }
    }




    private void spawnArmorStand(Location loc, String text, ChestData data) {
        org.bukkit.entity.ArmorStand stand = loc.getWorld().spawn(loc, org.bukkit.entity.ArmorStand.class);
        // Tag it so we can find and kill it later, even if its chunk was unloaded
        stand.addScoreboardTag("loot_hologram");

        stand.setVisible(false);
        stand.setMarker(true);
        stand.setGravity(false);
        stand.setCustomName(text);
        stand.setCustomNameVisible(true);
        stand.setSilent(true);
        stand.setSmall(true);

        data.getHolograms().add(stand); // Track it in-memory
    }

    public void killAllHologramArmorStands() {
        // Loop through every world
        for (org.bukkit.World world : plugin.getServer().getWorlds()) {
            // Only loaded chunks are visible; unloaded ones will get cleaned when they load if you also use the ChunkLoad listener
            for (org.bukkit.Chunk chunk : world.getLoadedChunks()) {
                for (org.bukkit.entity.Entity e : chunk.getEntities()) {
                    if (e instanceof org.bukkit.entity.ArmorStand stand
                        && stand.getScoreboardTags().contains("loot_hologram")) {
                        stand.remove();
                    }
                }
            }
        }
    }



    private String formatTierLine(String name, String tierText, int tier) {
        String fullPrefix = name; // just "Loot Chest" by default

        // Gradient from left to right (smooth), over Loot Chest
        ChatColor[] gradient = getSmoothGradientForTier(tier, fullPrefix.length());

        StringBuilder sb = new StringBuilder();

        // Apply gradient to Loot Chest
        for (int i = 0; i < fullPrefix.length(); i++) {
            sb.append(gradient[i]).append(fullPrefix.charAt(i));
        }

        // Append non-bold bracket + tier
        sb.append(ChatColor.RESET).append(" ").append(ChatColor.DARK_GRAY).append("[").append(ChatColor.GRAY)
            .append(tierText).append(ChatColor.DARK_GRAY).append("]");

        return sb.toString();
    }


    private ChatColor[] getSmoothGradientForTier(int tier, int length) {
        java.awt.Color start, end;

        switch (tier) {
            case 1: start = new java.awt.Color(255, 255, 255); end = new java.awt.Color(180, 180, 180); break;
            case 2: start = new java.awt.Color(0, 255, 0);     end = new java.awt.Color(0, 150, 0);     break;
            case 3: start = new java.awt.Color(0, 255, 255);   end = new java.awt.Color(0, 100, 255);   break;
            case 4: start = new java.awt.Color(255, 0, 255);   end = new java.awt.Color(100, 0, 150);   break;
            case 5: start = new java.awt.Color(255, 215, 0);   end = new java.awt.Color(255, 140, 0);   break;
            case 6: start = new java.awt.Color(255, 0, 0);     end = new java.awt.Color(150, 0, 0);     break;
            default: start = new java.awt.Color(200, 200, 200); end = new java.awt.Color(100, 100, 100); break;
        }

        ChatColor[] result = new ChatColor[length];
        for (int i = 0; i < length; i++) {
            float ratio = (float) i / (length - 1);
            int r = (int) (start.getRed() * (1 - ratio) + end.getRed() * ratio);
            int g = (int) (start.getGreen() * (1 - ratio) + end.getGreen() * ratio);
            int b = (int) (start.getBlue() * (1 - ratio) + end.getBlue() * ratio);
            result[i] = ChatColor.of(new java.awt.Color(r, g, b));
        }
        return result;
    }


    private String toRoman(int number) {
        String[] romanNumerals = {
            "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"
        };
        return (number >= 1 && number <= 10) ? romanNumerals[number - 1] : String.valueOf(number);
    }


    private void startParticleTask(int chestId, Location loc, int tier) {
        cancelParticleTask(chestId);
        // Repeat every 20 ticks
        org.bukkit.scheduler.BukkitTask task = plugin.getServer().getScheduler().runTaskTimer(
            plugin,
            () -> {
                if (loc.getBlock().getType() == Material.CHEST) {
                    ParticleUtils.displayTierParticles(loc, tier);
                }
            },
            0L,
            20L
        );
        chestParticleTasks.put(chestId, task);
    }

    private void cancelParticleTask(int chestId) {
        if (chestParticleTasks.containsKey(chestId)) {
            chestParticleTasks.get(chestId).cancel();
            chestParticleTasks.remove(chestId);
        }
    }

    public boolean removeChest(int chestId) {
        Location loc = spawnedChests.get(chestId);
        if (loc == null) {
            plugin.getLogger().warning("[LootChestManager] No spawned chest found for ID " + chestId);
            return false;
        }

        // Remove the block itself
        Block block = loc.getBlock();
        if (block.getType() == Material.CHEST) {
            block.setType(Material.AIR);
        }

        // 1) Remove only this chest’s own holograms
        for (ChestData data : chestDataList) {
            if (data.getChestId() == chestId) {
                for (ArmorStand stand : data.getHolograms()) {
                    if (!stand.isDead()) {
                        stand.remove();
                    }
                }
                data.getHolograms().clear();
                break;
            }
        }

        // 2) Remove from the spawned map
        spawnedChests.remove(chestId);

        // 3) Cancel its particle task
        cancelParticleTask(chestId);

        plugin.getLogger().info("[LootChestManager] Removed chest " + chestId);
        return true;
    }


    // Respawn after cooldown
    public void respawnChest(int chestId) {
        plugin.getLogger().info("[LootChestManager] respawnChest called for chest " + chestId);

        ChestData data = null;
        for (ChestData cd : chestDataList) {
            if (cd.getChestId() == chestId) {
                data = cd;
                break;
            }
        }
        if (data == null) {
            plugin.getLogger().info("[LootChestManager] No ChestData found for chest " + chestId
                + "; cannot respawn!");
            return;
        }
        // Actually call spawnChest
        spawnChest(data);
        plugin.getLogger().info("[LootChestManager] Finished respawnChest for chest " + chestId);
    }

    // For the /lootchest list command
    public Collection<ChestData> getAllChestData() {
        return chestDataList;
    }

    // So we can add new data via a command
    public void addChestData(ChestData data) {
        chestDataList.add(data);
    }

    public JavaPlugin getPlugin() {
        return plugin;
    }

    // Check if a given location belongs to a spawned chest
    public Integer getChestIdAtLocation(Location location) {
        for (java.util.Map.Entry<Integer, Location> entry : spawnedChests.entrySet()) {
            if (entry.getValue().equals(location)) {
                return entry.getKey();
            }
        }
        return null;
    }

    public int getTierForChest(int chestId) {
        for (ChestData data : chestDataList) {
            if (data.getChestId() == chestId) {
                return data.getTier();
            }
        }
        return -1;
    }


    public void removeAllChests() {
        List<Integer> ids = new ArrayList<>(spawnedChests.keySet());
        for (int chestId : ids) {
            removeChest(chestId);
        }
    }


    public boolean clearChest(int chestId) {
        Location loc = spawnedChests.get(chestId);
        if (loc == null) {
            plugin.getLogger().warning("[LootChestManager] No spawned chest found for ID " + chestId);
            return false;
        }

        Block block = loc.getBlock();
        if (!(block.getState() instanceof org.bukkit.block.Chest)) {
            plugin.getLogger().warning("[LootChestManager] Block at " + loc + " is not a chest!");
            return false;
        }

        org.bukkit.block.Chest chestState = (org.bukkit.block.Chest) block.getState();
        chestState.getBlockInventory().clear();
        chestState.update(true);
        plugin.getLogger().info("[LootChestManager] Cleared contents of chest " + chestId);
        return true;
    }

    public void clearAllChests() {
        // Make a copy of the IDs to avoid CME if spawn map is modified
        List<Integer> ids = new ArrayList<>(spawnedChests.keySet());
        for (int chestId : ids) {
            clearChest(chestId);
        }
    }

    public CooldownManager getCooldownManager() {
        return cooldownManager;
    }

    public ItemStack getRandomLootForTier(int tier) {
        // Example: 20% chance to drop a potion
        double potionChance = 0.2;
        if (Math.random() < potionChance) {
            Collection<PotionTemplate> potionTemplates = potionManager.getAllTemplates();
            List<PotionTemplate> availablePotions = new ArrayList<>(potionTemplates);
            if (!availablePotions.isEmpty()) {
                // Randomly pick one potion template
                PotionTemplate selected = availablePotions.get(new Random().nextInt(availablePotions.size()));
                // Create a new potion instance and convert it to an ItemStack
                PotionInstance instance = potionManager.createInstance(selected);
                return instance.toItemStack(plugin);
            }
        }

        // If no potion is chosen, or if none exist, fallback to custom item logic
        int minLevel, maxLevel;
        switch (tier) {
            case 1:
                minLevel = 1;
                maxLevel = 12;
                break;
            case 2:
                minLevel = 13;
                maxLevel = 25;
                break;
            case 3:
                minLevel = 26;
                maxLevel = 38;
                break;
            case 4:
                minLevel = 39;
                maxLevel = 50;
                break;
            case 5:
                minLevel = 51;
                maxLevel = 62;
                break;
            case 6:
                minLevel = 63;
                maxLevel = 75;
                break;
            case 7:
                minLevel = 76;
                maxLevel = 88;
                break;
            case 8:
                minLevel = 89;
                maxLevel = 100;
                break;
            default:
                return null;
        }

        // Gather matching custom items
        List<CustomItem> matching = new ArrayList<>();
        for (CustomItem cItem : ItemManager.getInstance().getAllTemplates().values()) {
            int req = cItem.getLevelRequirement();
            if (req >= minLevel && req <= maxLevel) {
                matching.add(cItem);
            }
        }

        if (matching.isEmpty()) {
            return null; // No matching custom item: chest gets no loot
        }

        // Pick one custom item at random from the templates
        // Pick one custom item at random from the templates
        CustomItem chosen = matching.get(new Random().nextInt(matching.size()));

// Create a new unique instance based on the chosen template using the 12-parameter constructor
        CustomItem newInstance = new CustomItem(
            chosen.getId(),
            chosen.getBaseName(),
            chosen.getRarity(),
            chosen.getLevelRequirement(),
            chosen.getClassRequirement(),
            chosen.getMaterial(),
            chosen.getHpRange(),
            chosen.getDefRange(),
            chosen.getStrRange(),
            chosen.getAgiRange(),
            chosen.getIntelRange(),
            chosen.getDexRange()
        );
// Register the new instance so it's tracked properly
        ItemManager.getInstance().addInstance(newInstance);

        return ItemUtil.createItemStackFromCustomItem(newInstance, 1, null);

    }
}
