package me.nakilex.levelplugin.runes.gui;

import me.nakilex.levelplugin.Main;
import me.nakilex.levelplugin.player.level.managers.LevelManager;
import me.nakilex.levelplugin.runes.manager.RunesManager;
import me.nakilex.levelplugin.runes.model.Rune;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryView;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.*;

public class EquipRunesGUI implements Listener {
    private final Main plugin;
    private final RunesManager runesManager;
    private final IdentifyRunesGUI identifyGui;

    public static final String TITLE = ChatColor.DARK_GRAY + "Equip Runes";
    private static final int SIZE = 54;

    private static final Set<Integer> UNIQUE_SLOTS = Set.of(0, 4, 8, 47, 51);
    private static final Set<Integer> NORMAL_SLOTS = Set.of(
        1,2,5,6,9,11,13,15,17,18,20,22,24,26,27,29,31,33,35,36,38,40,42,44,45,48,49,52,53
    );

    private static final Map<Integer, Integer> UNLOCK_LEVELS = new HashMap<>();
    static {
        List<Integer> snake = new ArrayList<>();
        for (int col = 0; col < 9; col++) {
            if (col % 2 == 0) {
                for (int row = 5; row >= 0; row--) snake.add(row * 9 + col);
            } else {
                for (int row = 0; row < 6; row++) snake.add(row * 9 + col);
            }
        }
        int step = 0;
        for (int slot : snake) {
            if (UNIQUE_SLOTS.contains(slot) || NORMAL_SLOTS.contains(slot)) {
                UNLOCK_LEVELS.put(slot, step * 3);
                step++;
            }
        }
    }

    public EquipRunesGUI(Main plugin, RunesManager runesManager, IdentifyRunesGUI identifyGui) {
        this.plugin = plugin;
        this.runesManager = runesManager;
        this.identifyGui = (identifyGui != null) ? identifyGui : new IdentifyRunesGUI(plugin, runesManager);
    }

    public Inventory createInventory(Player player) {
        Inventory inv = Bukkit.createInventory(null, SIZE, TITLE);
        int playerLevel = LevelManager.getInstance().getLevel(player);

        for (int slot = 0; slot < SIZE; slot++) {
            if (UNIQUE_SLOTS.contains(slot)) {
                int req = UNLOCK_LEVELS.get(slot);
                if (playerLevel < req) inv.setItem(slot, createPlaceholder(Material.WHITE_STAINED_GLASS_PANE, req));
            } else if (NORMAL_SLOTS.contains(slot)) {
                int req = UNLOCK_LEVELS.get(slot);
                if (playerLevel < req) inv.setItem(slot, createPlaceholder(Material.RED_STAINED_GLASS_PANE, req));
            } else {
                inv.setItem(slot, createFiller(Material.GRAY_STAINED_GLASS_PANE));
            }
        }

        for (Rune rune : runesManager.getEquippedRunes(player)) {
            Set<Integer> target = rune.isUnique() ? UNIQUE_SLOTS : NORMAL_SLOTS;
            for (int slot : target) {
                if (playerLevel >= UNLOCK_LEVELS.get(slot) && inv.getItem(slot) == null) {
                    inv.setItem(slot, identifyGui.createIdentifiedRuneItem(rune));
                    break;
                }
            }
        }
        return inv;
    }

    public void open(Player player) {
        player.openInventory(createInventory(player));
    }

    private boolean isIdentifiedRune(ItemStack stack) {
        if (stack == null || !stack.hasItemMeta()) return false;
        String id = stack.getItemMeta()
            .getPersistentDataContainer()
            .get(runesManager.getRuneKey(), PersistentDataType.STRING);
        if (id == null) return false;
        return runesManager.getRuneById(id) != null;
    }

    private boolean isEquipGUI(InventoryView view) {
        return TITLE.equals(view.getTitle());
    }

    private String getSafeName(ItemStack item) {
        if (item == null) return "<none>";
        ItemMeta meta = item.getItemMeta();
        return (meta != null && meta.hasDisplayName()) ? meta.getDisplayName() : item.getType().toString();
    }

    private ItemStack createPlaceholder(Material mat, int unlockLevel) {
        ItemStack pane = new ItemStack(mat);
        ItemMeta meta = pane.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(ChatColor.RED + "Locked Slot");
            meta.setLore(Arrays.asList(
                ChatColor.GRAY + "🔒 Unlocks at level " + ChatColor.WHITE + unlockLevel,
                ChatColor.DARK_GRAY + "Place runes here after unlocking"
            ));
            pane.setItemMeta(meta);
        }
        return pane;
    }

    private ItemStack createFiller(Material mat) {
        ItemStack pane = new ItemStack(mat);
        ItemMeta meta = pane.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(" ");
            pane.setItemMeta(meta);
        }
        return pane;
    }

    @EventHandler(ignoreCancelled = true)
    public void onInventoryClick(InventoryClickEvent e) {
        InventoryView view = e.getView();
        if (!isEquipGUI(view)) return;

        int slot = e.getRawSlot();
        InventoryAction action = e.getAction();
        Inventory clickedInv = e.getClickedInventory();
        ItemStack clicked = e.getCurrentItem();
        ItemStack cursor = e.getCursor();
        Player p = (Player) e.getWhoClicked();
        int lvl = LevelManager.getInstance().getLevel(p);

        // Debug context
        plugin.getLogger().info(String.format(
            "[DBG] slot=%d inv=%s action=%s clicked=%s cursor=%s lvl=%d req=%s",
            slot,
            (clickedInv==view.getTopInventory()?"TOP":"BOTTOM"),
            action,
            clicked!=null?clicked.getType():"null",
            cursor!=null?cursor.getType():"null",
            lvl,
            UNLOCK_LEVELS.get(slot)
        ));

        // Unequip
        if (clickedInv == view.getTopInventory()
            && (action == InventoryAction.PICKUP_ONE || action == InventoryAction.PICKUP_ALL)) {
            e.setCancelled(true);
            if (clicked != null && isIdentifiedRune(clicked) && lvl >= UNLOCK_LEVELS.get(slot)) {
                String id = clicked.getItemMeta().getPersistentDataContainer().get(
                    runesManager.getRuneKey(), PersistentDataType.STRING);
                Rune rune = runesManager.getRuneById(id);
                runesManager.unequipRune(p, rune);
                Bukkit.getLogger().info("[DBG] Unequipped " + id);
                ItemStack one = clicked.clone().asOne();
                int empty = p.getInventory().firstEmpty();
                if (empty == -1) p.getWorld().dropItemNaturally(p.getLocation(), one);
                else p.getInventory().setItem(empty, one);
                p.sendMessage(ChatColor.YELLOW + "Unequipped rune: " + getSafeName(clicked));
                open(p);
            }
            return;
        }

        // Shift-click equip from player inv
        if (e.isShiftClick() && clickedInv == view.getBottomInventory() && clicked != null && isIdentifiedRune(clicked)) {
            e.setCancelled(true);
            String id = clicked.getItemMeta().getPersistentDataContainer().get(
                runesManager.getRuneKey(), PersistentDataType.STRING);
            Rune rune = runesManager.getRuneById(id);
            ItemStack book = identifyGui.createIdentifiedRuneItem(rune);
            boolean success = runesManager.equipRune(p, book);
            Bukkit.getLogger().info("[DBG] Shift-equip " + id + " result=" + success);
            if (success) {
                clicked.setAmount(clicked.getAmount() - 1);
                if (clicked.getAmount() <= 0) clickedInv.setItem(e.getSlot(), null);
                p.sendMessage(ChatColor.GREEN + "Equipped rune: " + getSafeName(book));
            } else {
                p.sendMessage(ChatColor.RED + "Failed to equip rune: " + getSafeName(book));
            }
            open(p);
            return;
        }

        // Direct place into GUI
        if (clickedInv == view.getTopInventory()
            && (action == InventoryAction.PLACE_ONE || action == InventoryAction.PLACE_ALL || action == InventoryAction.PLACE_SOME)) {
            e.setCancelled(true);
            if (cursor != null && isIdentifiedRune(cursor) && lvl >= UNLOCK_LEVELS.get(slot)) {
                String id = cursor.getItemMeta().getPersistentDataContainer().get(
                    runesManager.getRuneKey(), PersistentDataType.STRING);
                Rune rune = runesManager.getRuneById(id);
                ItemStack book = identifyGui.createIdentifiedRuneItem(rune);
                boolean success = runesManager.equipRune(p, book);
                Bukkit.getLogger().info("[DBG] Direct-equip " + id + " result=" + success);
                if (success) {
                    cursor.setAmount(cursor.getAmount() - 1);
                    e.setCursor(cursor.getAmount() > 0 ? cursor : null);
                    p.sendMessage(ChatColor.GREEN + "Equipped rune: " + getSafeName(book));
                    open(p);
                } else {
                    p.sendMessage(ChatColor.RED + "Failed to equip rune: " + getSafeName(book));
                }
            }
            return;
        }

        // Cancel any other top inv clicks
        if (clickedInv == view.getTopInventory()) {
            e.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onInventoryDrag(InventoryDragEvent e) {
        if (!isEquipGUI(e.getView())) return;
        Player p = (Player) e.getWhoClicked();
        int lvl = LevelManager.getInstance().getLevel(p);
        e.getNewItems().forEach((slot, stack) -> {
            if (slot < SIZE && (!isIdentifiedRune(stack) || lvl < UNLOCK_LEVELS.get(slot))) {
                e.setCancelled(true);
            }
        });
    }
}
